gdjs.Overworld2Code = {};
gdjs.Overworld2Code.GDPlayerObjects1= [];
gdjs.Overworld2Code.GDPlayerObjects2= [];
gdjs.Overworld2Code.GDNPCObjects1= [];
gdjs.Overworld2Code.GDNPCObjects2= [];
gdjs.Overworld2Code.GDDock1Objects1= [];
gdjs.Overworld2Code.GDDock1Objects2= [];
gdjs.Overworld2Code.GDTree1Objects1= [];
gdjs.Overworld2Code.GDTree1Objects2= [];
gdjs.Overworld2Code.GDTree2Objects1= [];
gdjs.Overworld2Code.GDTree2Objects2= [];
gdjs.Overworld2Code.GDBush1Objects1= [];
gdjs.Overworld2Code.GDBush1Objects2= [];
gdjs.Overworld2Code.GDHouse1Objects1= [];
gdjs.Overworld2Code.GDHouse1Objects2= [];
gdjs.Overworld2Code.GDHouse2Objects1= [];
gdjs.Overworld2Code.GDHouse2Objects2= [];
gdjs.Overworld2Code.GDCornerWaterObjects1= [];
gdjs.Overworld2Code.GDCornerWaterObjects2= [];
gdjs.Overworld2Code.GDWaterCorner2Objects1= [];
gdjs.Overworld2Code.GDWaterCorner2Objects2= [];
gdjs.Overworld2Code.GDGrassObjects1= [];
gdjs.Overworld2Code.GDGrassObjects2= [];
gdjs.Overworld2Code.GDWaterEdgeRightObjects1= [];
gdjs.Overworld2Code.GDWaterEdgeRightObjects2= [];
gdjs.Overworld2Code.GDNewTiledSpriteObjects1= [];
gdjs.Overworld2Code.GDNewTiledSpriteObjects2= [];
gdjs.Overworld2Code.GDWater1Objects1= [];
gdjs.Overworld2Code.GDWater1Objects2= [];
gdjs.Overworld2Code.GDRoad1Objects1= [];
gdjs.Overworld2Code.GDRoad1Objects2= [];
gdjs.Overworld2Code.GDRoadEdge1Objects1= [];
gdjs.Overworld2Code.GDRoadEdge1Objects2= [];
gdjs.Overworld2Code.GDCollisionDetectObjects1= [];
gdjs.Overworld2Code.GDCollisionDetectObjects2= [];
gdjs.Overworld2Code.GDDialogueObjects1= [];
gdjs.Overworld2Code.GDDialogueObjects2= [];
gdjs.Overworld2Code.GDEObjects1= [];
gdjs.Overworld2Code.GDEObjects2= [];
gdjs.Overworld2Code.GDE2Objects1= [];
gdjs.Overworld2Code.GDE2Objects2= [];
gdjs.Overworld2Code.GDYesButtonObjects1= [];
gdjs.Overworld2Code.GDYesButtonObjects2= [];
gdjs.Overworld2Code.GDNoButtonObjects1= [];
gdjs.Overworld2Code.GDNoButtonObjects2= [];
gdjs.Overworld2Code.GDShadedDarkJoystickObjects1= [];
gdjs.Overworld2Code.GDShadedDarkJoystickObjects2= [];
gdjs.Overworld2Code.GDTargetRoundButtonObjects1= [];
gdjs.Overworld2Code.GDTargetRoundButtonObjects2= [];
gdjs.Overworld2Code.GDEmptyCloudBackgroundObjects1= [];
gdjs.Overworld2Code.GDEmptyCloudBackgroundObjects2= [];
gdjs.Overworld2Code.GDGreenSmallTree3Objects1= [];
gdjs.Overworld2Code.GDGreenSmallTree3Objects2= [];
gdjs.Overworld2Code.GDWoodYellowBarObjects1= [];
gdjs.Overworld2Code.GDWoodYellowBarObjects2= [];
gdjs.Overworld2Code.GDGoldObjects1= [];
gdjs.Overworld2Code.GDGoldObjects2= [];
gdjs.Overworld2Code.GDGreyButtonObjects1= [];
gdjs.Overworld2Code.GDGreyButtonObjects2= [];
gdjs.Overworld2Code.GDYellowButtonObjects1= [];
gdjs.Overworld2Code.GDYellowButtonObjects2= [];
gdjs.Overworld2Code.GDGreenButtonObjects1= [];
gdjs.Overworld2Code.GDGreenButtonObjects2= [];
gdjs.Overworld2Code.GDMaleCasualHoodieObjects1= [];
gdjs.Overworld2Code.GDMaleCasualHoodieObjects2= [];
gdjs.Overworld2Code.GDMaleCharacter9Objects1= [];
gdjs.Overworld2Code.GDMaleCharacter9Objects2= [];
gdjs.Overworld2Code.GDLargeExitButtonObjects1= [];
gdjs.Overworld2Code.GDLargeExitButtonObjects2= [];
gdjs.Overworld2Code.GDHelpObjects1= [];
gdjs.Overworld2Code.GDHelpObjects2= [];
gdjs.Overworld2Code.GDMenuObjects1= [];
gdjs.Overworld2Code.GDMenuObjects2= [];
gdjs.Overworld2Code.GDBlueButtonObjects1= [];
gdjs.Overworld2Code.GDBlueButtonObjects2= [];
gdjs.Overworld2Code.GDGreyButton2Objects1= [];
gdjs.Overworld2Code.GDGreyButton2Objects2= [];
gdjs.Overworld2Code.GDPlusObjects1= [];
gdjs.Overworld2Code.GDPlusObjects2= [];
gdjs.Overworld2Code.GDBlackSpaceObjects1= [];
gdjs.Overworld2Code.GDBlackSpaceObjects2= [];
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggleObjects1= [];
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggleObjects2= [];
gdjs.Overworld2Code.GDGreenButtonWithStoneFrameObjects1= [];
gdjs.Overworld2Code.GDGreenButtonWithStoneFrameObjects2= [];
gdjs.Overworld2Code.GDGreenButtonWithStoneFrame2Objects1= [];
gdjs.Overworld2Code.GDGreenButtonWithStoneFrame2Objects2= [];
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggle2Objects1= [];
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggle2Objects2= [];
gdjs.Overworld2Code.GDApplyObjects1= [];
gdjs.Overworld2Code.GDApplyObjects2= [];
gdjs.Overworld2Code.GDLeftArrowObjects1= [];
gdjs.Overworld2Code.GDLeftArrowObjects2= [];
gdjs.Overworld2Code.GDPlus2Objects1= [];
gdjs.Overworld2Code.GDPlus2Objects2= [];
gdjs.Overworld2Code.GDTransitionObjects1= [];
gdjs.Overworld2Code.GDTransitionObjects2= [];
gdjs.Overworld2Code.GDTextBorderObjects1= [];
gdjs.Overworld2Code.GDTextBorderObjects2= [];


gdjs.Overworld2Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Apply"), gdjs.Overworld2Code.GDApplyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld2Code.GDApplyObjects1.length;i<l;++i) {
    if ( gdjs.Overworld2Code.GDApplyObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld2Code.GDApplyObjects1[k] = gdjs.Overworld2Code.GDApplyObjects1[i];
        ++k;
    }
}
gdjs.Overworld2Code.GDApplyObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Overworld3", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Plus2"), gdjs.Overworld2Code.GDPlus2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld2Code.GDPlus2Objects1.length;i<l;++i) {
    if ( gdjs.Overworld2Code.GDPlus2Objects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld2Code.GDPlus2Objects1[k] = gdjs.Overworld2Code.GDPlus2Objects1[i];
        ++k;
    }
}
gdjs.Overworld2Code.GDPlus2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Overworld", false);
}}

}


};

gdjs.Overworld2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Overworld2Code.GDPlayerObjects1.length = 0;
gdjs.Overworld2Code.GDPlayerObjects2.length = 0;
gdjs.Overworld2Code.GDNPCObjects1.length = 0;
gdjs.Overworld2Code.GDNPCObjects2.length = 0;
gdjs.Overworld2Code.GDDock1Objects1.length = 0;
gdjs.Overworld2Code.GDDock1Objects2.length = 0;
gdjs.Overworld2Code.GDTree1Objects1.length = 0;
gdjs.Overworld2Code.GDTree1Objects2.length = 0;
gdjs.Overworld2Code.GDTree2Objects1.length = 0;
gdjs.Overworld2Code.GDTree2Objects2.length = 0;
gdjs.Overworld2Code.GDBush1Objects1.length = 0;
gdjs.Overworld2Code.GDBush1Objects2.length = 0;
gdjs.Overworld2Code.GDHouse1Objects1.length = 0;
gdjs.Overworld2Code.GDHouse1Objects2.length = 0;
gdjs.Overworld2Code.GDHouse2Objects1.length = 0;
gdjs.Overworld2Code.GDHouse2Objects2.length = 0;
gdjs.Overworld2Code.GDCornerWaterObjects1.length = 0;
gdjs.Overworld2Code.GDCornerWaterObjects2.length = 0;
gdjs.Overworld2Code.GDWaterCorner2Objects1.length = 0;
gdjs.Overworld2Code.GDWaterCorner2Objects2.length = 0;
gdjs.Overworld2Code.GDGrassObjects1.length = 0;
gdjs.Overworld2Code.GDGrassObjects2.length = 0;
gdjs.Overworld2Code.GDWaterEdgeRightObjects1.length = 0;
gdjs.Overworld2Code.GDWaterEdgeRightObjects2.length = 0;
gdjs.Overworld2Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Overworld2Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Overworld2Code.GDWater1Objects1.length = 0;
gdjs.Overworld2Code.GDWater1Objects2.length = 0;
gdjs.Overworld2Code.GDRoad1Objects1.length = 0;
gdjs.Overworld2Code.GDRoad1Objects2.length = 0;
gdjs.Overworld2Code.GDRoadEdge1Objects1.length = 0;
gdjs.Overworld2Code.GDRoadEdge1Objects2.length = 0;
gdjs.Overworld2Code.GDCollisionDetectObjects1.length = 0;
gdjs.Overworld2Code.GDCollisionDetectObjects2.length = 0;
gdjs.Overworld2Code.GDDialogueObjects1.length = 0;
gdjs.Overworld2Code.GDDialogueObjects2.length = 0;
gdjs.Overworld2Code.GDEObjects1.length = 0;
gdjs.Overworld2Code.GDEObjects2.length = 0;
gdjs.Overworld2Code.GDE2Objects1.length = 0;
gdjs.Overworld2Code.GDE2Objects2.length = 0;
gdjs.Overworld2Code.GDYesButtonObjects1.length = 0;
gdjs.Overworld2Code.GDYesButtonObjects2.length = 0;
gdjs.Overworld2Code.GDNoButtonObjects1.length = 0;
gdjs.Overworld2Code.GDNoButtonObjects2.length = 0;
gdjs.Overworld2Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.Overworld2Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.Overworld2Code.GDTargetRoundButtonObjects1.length = 0;
gdjs.Overworld2Code.GDTargetRoundButtonObjects2.length = 0;
gdjs.Overworld2Code.GDEmptyCloudBackgroundObjects1.length = 0;
gdjs.Overworld2Code.GDEmptyCloudBackgroundObjects2.length = 0;
gdjs.Overworld2Code.GDGreenSmallTree3Objects1.length = 0;
gdjs.Overworld2Code.GDGreenSmallTree3Objects2.length = 0;
gdjs.Overworld2Code.GDWoodYellowBarObjects1.length = 0;
gdjs.Overworld2Code.GDWoodYellowBarObjects2.length = 0;
gdjs.Overworld2Code.GDGoldObjects1.length = 0;
gdjs.Overworld2Code.GDGoldObjects2.length = 0;
gdjs.Overworld2Code.GDGreyButtonObjects1.length = 0;
gdjs.Overworld2Code.GDGreyButtonObjects2.length = 0;
gdjs.Overworld2Code.GDYellowButtonObjects1.length = 0;
gdjs.Overworld2Code.GDYellowButtonObjects2.length = 0;
gdjs.Overworld2Code.GDGreenButtonObjects1.length = 0;
gdjs.Overworld2Code.GDGreenButtonObjects2.length = 0;
gdjs.Overworld2Code.GDMaleCasualHoodieObjects1.length = 0;
gdjs.Overworld2Code.GDMaleCasualHoodieObjects2.length = 0;
gdjs.Overworld2Code.GDMaleCharacter9Objects1.length = 0;
gdjs.Overworld2Code.GDMaleCharacter9Objects2.length = 0;
gdjs.Overworld2Code.GDLargeExitButtonObjects1.length = 0;
gdjs.Overworld2Code.GDLargeExitButtonObjects2.length = 0;
gdjs.Overworld2Code.GDHelpObjects1.length = 0;
gdjs.Overworld2Code.GDHelpObjects2.length = 0;
gdjs.Overworld2Code.GDMenuObjects1.length = 0;
gdjs.Overworld2Code.GDMenuObjects2.length = 0;
gdjs.Overworld2Code.GDBlueButtonObjects1.length = 0;
gdjs.Overworld2Code.GDBlueButtonObjects2.length = 0;
gdjs.Overworld2Code.GDGreyButton2Objects1.length = 0;
gdjs.Overworld2Code.GDGreyButton2Objects2.length = 0;
gdjs.Overworld2Code.GDPlusObjects1.length = 0;
gdjs.Overworld2Code.GDPlusObjects2.length = 0;
gdjs.Overworld2Code.GDBlackSpaceObjects1.length = 0;
gdjs.Overworld2Code.GDBlackSpaceObjects2.length = 0;
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.Overworld2Code.GDGreenButtonWithStoneFrameObjects1.length = 0;
gdjs.Overworld2Code.GDGreenButtonWithStoneFrameObjects2.length = 0;
gdjs.Overworld2Code.GDGreenButtonWithStoneFrame2Objects1.length = 0;
gdjs.Overworld2Code.GDGreenButtonWithStoneFrame2Objects2.length = 0;
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggle2Objects1.length = 0;
gdjs.Overworld2Code.GDSmallGreenPlasticRoundToggle2Objects2.length = 0;
gdjs.Overworld2Code.GDApplyObjects1.length = 0;
gdjs.Overworld2Code.GDApplyObjects2.length = 0;
gdjs.Overworld2Code.GDLeftArrowObjects1.length = 0;
gdjs.Overworld2Code.GDLeftArrowObjects2.length = 0;
gdjs.Overworld2Code.GDPlus2Objects1.length = 0;
gdjs.Overworld2Code.GDPlus2Objects2.length = 0;
gdjs.Overworld2Code.GDTransitionObjects1.length = 0;
gdjs.Overworld2Code.GDTransitionObjects2.length = 0;
gdjs.Overworld2Code.GDTextBorderObjects1.length = 0;
gdjs.Overworld2Code.GDTextBorderObjects2.length = 0;

gdjs.Overworld2Code.eventsList0(runtimeScene);

return;

}

gdjs['Overworld2Code'] = gdjs.Overworld2Code;
