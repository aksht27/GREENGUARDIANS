gdjs.Overworld4Code = {};
gdjs.Overworld4Code.GDPlayerObjects1= [];
gdjs.Overworld4Code.GDPlayerObjects2= [];
gdjs.Overworld4Code.GDNPCObjects1= [];
gdjs.Overworld4Code.GDNPCObjects2= [];
gdjs.Overworld4Code.GDDock1Objects1= [];
gdjs.Overworld4Code.GDDock1Objects2= [];
gdjs.Overworld4Code.GDTree1Objects1= [];
gdjs.Overworld4Code.GDTree1Objects2= [];
gdjs.Overworld4Code.GDTree2Objects1= [];
gdjs.Overworld4Code.GDTree2Objects2= [];
gdjs.Overworld4Code.GDBush1Objects1= [];
gdjs.Overworld4Code.GDBush1Objects2= [];
gdjs.Overworld4Code.GDHouse1Objects1= [];
gdjs.Overworld4Code.GDHouse1Objects2= [];
gdjs.Overworld4Code.GDHouse2Objects1= [];
gdjs.Overworld4Code.GDHouse2Objects2= [];
gdjs.Overworld4Code.GDCornerWaterObjects1= [];
gdjs.Overworld4Code.GDCornerWaterObjects2= [];
gdjs.Overworld4Code.GDWaterCorner2Objects1= [];
gdjs.Overworld4Code.GDWaterCorner2Objects2= [];
gdjs.Overworld4Code.GDGrassObjects1= [];
gdjs.Overworld4Code.GDGrassObjects2= [];
gdjs.Overworld4Code.GDWaterEdgeRightObjects1= [];
gdjs.Overworld4Code.GDWaterEdgeRightObjects2= [];
gdjs.Overworld4Code.GDNewTiledSpriteObjects1= [];
gdjs.Overworld4Code.GDNewTiledSpriteObjects2= [];
gdjs.Overworld4Code.GDWater1Objects1= [];
gdjs.Overworld4Code.GDWater1Objects2= [];
gdjs.Overworld4Code.GDRoad1Objects1= [];
gdjs.Overworld4Code.GDRoad1Objects2= [];
gdjs.Overworld4Code.GDRoadEdge1Objects1= [];
gdjs.Overworld4Code.GDRoadEdge1Objects2= [];
gdjs.Overworld4Code.GDCollisionDetectObjects1= [];
gdjs.Overworld4Code.GDCollisionDetectObjects2= [];
gdjs.Overworld4Code.GDDialogueObjects1= [];
gdjs.Overworld4Code.GDDialogueObjects2= [];
gdjs.Overworld4Code.GDEObjects1= [];
gdjs.Overworld4Code.GDEObjects2= [];
gdjs.Overworld4Code.GDE2Objects1= [];
gdjs.Overworld4Code.GDE2Objects2= [];
gdjs.Overworld4Code.GDYesButtonObjects1= [];
gdjs.Overworld4Code.GDYesButtonObjects2= [];
gdjs.Overworld4Code.GDNoButtonObjects1= [];
gdjs.Overworld4Code.GDNoButtonObjects2= [];
gdjs.Overworld4Code.GDShadedDarkJoystickObjects1= [];
gdjs.Overworld4Code.GDShadedDarkJoystickObjects2= [];
gdjs.Overworld4Code.GDTargetRoundButtonObjects1= [];
gdjs.Overworld4Code.GDTargetRoundButtonObjects2= [];
gdjs.Overworld4Code.GDEmptyCloudBackgroundObjects1= [];
gdjs.Overworld4Code.GDEmptyCloudBackgroundObjects2= [];
gdjs.Overworld4Code.GDGreenSmallTree3Objects1= [];
gdjs.Overworld4Code.GDGreenSmallTree3Objects2= [];
gdjs.Overworld4Code.GDWoodYellowBarObjects1= [];
gdjs.Overworld4Code.GDWoodYellowBarObjects2= [];
gdjs.Overworld4Code.GDGoldObjects1= [];
gdjs.Overworld4Code.GDGoldObjects2= [];
gdjs.Overworld4Code.GDGreyButtonObjects1= [];
gdjs.Overworld4Code.GDGreyButtonObjects2= [];
gdjs.Overworld4Code.GDYellowButtonObjects1= [];
gdjs.Overworld4Code.GDYellowButtonObjects2= [];
gdjs.Overworld4Code.GDGreenButtonObjects1= [];
gdjs.Overworld4Code.GDGreenButtonObjects2= [];
gdjs.Overworld4Code.GDMaleCasualHoodieObjects1= [];
gdjs.Overworld4Code.GDMaleCasualHoodieObjects2= [];
gdjs.Overworld4Code.GDMaleCharacter9Objects1= [];
gdjs.Overworld4Code.GDMaleCharacter9Objects2= [];
gdjs.Overworld4Code.GDLargeExitButtonObjects1= [];
gdjs.Overworld4Code.GDLargeExitButtonObjects2= [];
gdjs.Overworld4Code.GDHelpObjects1= [];
gdjs.Overworld4Code.GDHelpObjects2= [];
gdjs.Overworld4Code.GDMenuObjects1= [];
gdjs.Overworld4Code.GDMenuObjects2= [];
gdjs.Overworld4Code.GDBlueButtonObjects1= [];
gdjs.Overworld4Code.GDBlueButtonObjects2= [];
gdjs.Overworld4Code.GDGreyButton2Objects1= [];
gdjs.Overworld4Code.GDGreyButton2Objects2= [];
gdjs.Overworld4Code.GDPlusObjects1= [];
gdjs.Overworld4Code.GDPlusObjects2= [];
gdjs.Overworld4Code.GDBlackSpaceObjects1= [];
gdjs.Overworld4Code.GDBlackSpaceObjects2= [];
gdjs.Overworld4Code.GDSmallGreenPlasticRoundToggleObjects1= [];
gdjs.Overworld4Code.GDSmallGreenPlasticRoundToggleObjects2= [];
gdjs.Overworld4Code.GDGreenLeavesObjects1= [];
gdjs.Overworld4Code.GDGreenLeavesObjects2= [];
gdjs.Overworld4Code.GDBuy3Objects1= [];
gdjs.Overworld4Code.GDBuy3Objects2= [];
gdjs.Overworld4Code.GDBuy4Objects1= [];
gdjs.Overworld4Code.GDBuy4Objects2= [];
gdjs.Overworld4Code.GDBuy5Objects1= [];
gdjs.Overworld4Code.GDBuy5Objects2= [];
gdjs.Overworld4Code.GDBuy6Objects1= [];
gdjs.Overworld4Code.GDBuy6Objects2= [];
gdjs.Overworld4Code.GDBuy7Objects1= [];
gdjs.Overworld4Code.GDBuy7Objects2= [];
gdjs.Overworld4Code.GDBuy8Objects1= [];
gdjs.Overworld4Code.GDBuy8Objects2= [];
gdjs.Overworld4Code.GDBuy9Objects1= [];
gdjs.Overworld4Code.GDBuy9Objects2= [];
gdjs.Overworld4Code.GDBuy10Objects1= [];
gdjs.Overworld4Code.GDBuy10Objects2= [];
gdjs.Overworld4Code.GDTransitionObjects1= [];
gdjs.Overworld4Code.GDTransitionObjects2= [];
gdjs.Overworld4Code.GDTextBorderObjects1= [];
gdjs.Overworld4Code.GDTextBorderObjects2= [];


gdjs.Overworld4Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Plus"), gdjs.Overworld4Code.GDPlusObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDPlusObjects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDPlusObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDPlusObjects1[k] = gdjs.Overworld4Code.GDPlusObjects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDPlusObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Overworld", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy4"), gdjs.Overworld4Code.GDBuy4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy4Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy4Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy4Objects1[k] = gdjs.Overworld4Code.GDBuy4Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy4Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy3"), gdjs.Overworld4Code.GDBuy3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy3Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy3Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy3Objects1[k] = gdjs.Overworld4Code.GDBuy3Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy3Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy5"), gdjs.Overworld4Code.GDBuy5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy5Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy5Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy5Objects1[k] = gdjs.Overworld4Code.GDBuy5Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy5Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy6"), gdjs.Overworld4Code.GDBuy6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy6Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy6Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy6Objects1[k] = gdjs.Overworld4Code.GDBuy6Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy6Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy7"), gdjs.Overworld4Code.GDBuy7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy7Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy7Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy7Objects1[k] = gdjs.Overworld4Code.GDBuy7Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy7Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy8"), gdjs.Overworld4Code.GDBuy8Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy8Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy8Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy8Objects1[k] = gdjs.Overworld4Code.GDBuy8Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy8Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy9"), gdjs.Overworld4Code.GDBuy9Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy9Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy9Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy9Objects1[k] = gdjs.Overworld4Code.GDBuy9Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy9Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy10"), gdjs.Overworld4Code.GDBuy10Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld4Code.GDBuy10Objects1.length;i<l;++i) {
    if ( gdjs.Overworld4Code.GDBuy10Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld4Code.GDBuy10Objects1[k] = gdjs.Overworld4Code.GDBuy10Objects1[i];
        ++k;
    }
}
gdjs.Overworld4Code.GDBuy10Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


};

gdjs.Overworld4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Overworld4Code.GDPlayerObjects1.length = 0;
gdjs.Overworld4Code.GDPlayerObjects2.length = 0;
gdjs.Overworld4Code.GDNPCObjects1.length = 0;
gdjs.Overworld4Code.GDNPCObjects2.length = 0;
gdjs.Overworld4Code.GDDock1Objects1.length = 0;
gdjs.Overworld4Code.GDDock1Objects2.length = 0;
gdjs.Overworld4Code.GDTree1Objects1.length = 0;
gdjs.Overworld4Code.GDTree1Objects2.length = 0;
gdjs.Overworld4Code.GDTree2Objects1.length = 0;
gdjs.Overworld4Code.GDTree2Objects2.length = 0;
gdjs.Overworld4Code.GDBush1Objects1.length = 0;
gdjs.Overworld4Code.GDBush1Objects2.length = 0;
gdjs.Overworld4Code.GDHouse1Objects1.length = 0;
gdjs.Overworld4Code.GDHouse1Objects2.length = 0;
gdjs.Overworld4Code.GDHouse2Objects1.length = 0;
gdjs.Overworld4Code.GDHouse2Objects2.length = 0;
gdjs.Overworld4Code.GDCornerWaterObjects1.length = 0;
gdjs.Overworld4Code.GDCornerWaterObjects2.length = 0;
gdjs.Overworld4Code.GDWaterCorner2Objects1.length = 0;
gdjs.Overworld4Code.GDWaterCorner2Objects2.length = 0;
gdjs.Overworld4Code.GDGrassObjects1.length = 0;
gdjs.Overworld4Code.GDGrassObjects2.length = 0;
gdjs.Overworld4Code.GDWaterEdgeRightObjects1.length = 0;
gdjs.Overworld4Code.GDWaterEdgeRightObjects2.length = 0;
gdjs.Overworld4Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Overworld4Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Overworld4Code.GDWater1Objects1.length = 0;
gdjs.Overworld4Code.GDWater1Objects2.length = 0;
gdjs.Overworld4Code.GDRoad1Objects1.length = 0;
gdjs.Overworld4Code.GDRoad1Objects2.length = 0;
gdjs.Overworld4Code.GDRoadEdge1Objects1.length = 0;
gdjs.Overworld4Code.GDRoadEdge1Objects2.length = 0;
gdjs.Overworld4Code.GDCollisionDetectObjects1.length = 0;
gdjs.Overworld4Code.GDCollisionDetectObjects2.length = 0;
gdjs.Overworld4Code.GDDialogueObjects1.length = 0;
gdjs.Overworld4Code.GDDialogueObjects2.length = 0;
gdjs.Overworld4Code.GDEObjects1.length = 0;
gdjs.Overworld4Code.GDEObjects2.length = 0;
gdjs.Overworld4Code.GDE2Objects1.length = 0;
gdjs.Overworld4Code.GDE2Objects2.length = 0;
gdjs.Overworld4Code.GDYesButtonObjects1.length = 0;
gdjs.Overworld4Code.GDYesButtonObjects2.length = 0;
gdjs.Overworld4Code.GDNoButtonObjects1.length = 0;
gdjs.Overworld4Code.GDNoButtonObjects2.length = 0;
gdjs.Overworld4Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.Overworld4Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.Overworld4Code.GDTargetRoundButtonObjects1.length = 0;
gdjs.Overworld4Code.GDTargetRoundButtonObjects2.length = 0;
gdjs.Overworld4Code.GDEmptyCloudBackgroundObjects1.length = 0;
gdjs.Overworld4Code.GDEmptyCloudBackgroundObjects2.length = 0;
gdjs.Overworld4Code.GDGreenSmallTree3Objects1.length = 0;
gdjs.Overworld4Code.GDGreenSmallTree3Objects2.length = 0;
gdjs.Overworld4Code.GDWoodYellowBarObjects1.length = 0;
gdjs.Overworld4Code.GDWoodYellowBarObjects2.length = 0;
gdjs.Overworld4Code.GDGoldObjects1.length = 0;
gdjs.Overworld4Code.GDGoldObjects2.length = 0;
gdjs.Overworld4Code.GDGreyButtonObjects1.length = 0;
gdjs.Overworld4Code.GDGreyButtonObjects2.length = 0;
gdjs.Overworld4Code.GDYellowButtonObjects1.length = 0;
gdjs.Overworld4Code.GDYellowButtonObjects2.length = 0;
gdjs.Overworld4Code.GDGreenButtonObjects1.length = 0;
gdjs.Overworld4Code.GDGreenButtonObjects2.length = 0;
gdjs.Overworld4Code.GDMaleCasualHoodieObjects1.length = 0;
gdjs.Overworld4Code.GDMaleCasualHoodieObjects2.length = 0;
gdjs.Overworld4Code.GDMaleCharacter9Objects1.length = 0;
gdjs.Overworld4Code.GDMaleCharacter9Objects2.length = 0;
gdjs.Overworld4Code.GDLargeExitButtonObjects1.length = 0;
gdjs.Overworld4Code.GDLargeExitButtonObjects2.length = 0;
gdjs.Overworld4Code.GDHelpObjects1.length = 0;
gdjs.Overworld4Code.GDHelpObjects2.length = 0;
gdjs.Overworld4Code.GDMenuObjects1.length = 0;
gdjs.Overworld4Code.GDMenuObjects2.length = 0;
gdjs.Overworld4Code.GDBlueButtonObjects1.length = 0;
gdjs.Overworld4Code.GDBlueButtonObjects2.length = 0;
gdjs.Overworld4Code.GDGreyButton2Objects1.length = 0;
gdjs.Overworld4Code.GDGreyButton2Objects2.length = 0;
gdjs.Overworld4Code.GDPlusObjects1.length = 0;
gdjs.Overworld4Code.GDPlusObjects2.length = 0;
gdjs.Overworld4Code.GDBlackSpaceObjects1.length = 0;
gdjs.Overworld4Code.GDBlackSpaceObjects2.length = 0;
gdjs.Overworld4Code.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.Overworld4Code.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.Overworld4Code.GDGreenLeavesObjects1.length = 0;
gdjs.Overworld4Code.GDGreenLeavesObjects2.length = 0;
gdjs.Overworld4Code.GDBuy3Objects1.length = 0;
gdjs.Overworld4Code.GDBuy3Objects2.length = 0;
gdjs.Overworld4Code.GDBuy4Objects1.length = 0;
gdjs.Overworld4Code.GDBuy4Objects2.length = 0;
gdjs.Overworld4Code.GDBuy5Objects1.length = 0;
gdjs.Overworld4Code.GDBuy5Objects2.length = 0;
gdjs.Overworld4Code.GDBuy6Objects1.length = 0;
gdjs.Overworld4Code.GDBuy6Objects2.length = 0;
gdjs.Overworld4Code.GDBuy7Objects1.length = 0;
gdjs.Overworld4Code.GDBuy7Objects2.length = 0;
gdjs.Overworld4Code.GDBuy8Objects1.length = 0;
gdjs.Overworld4Code.GDBuy8Objects2.length = 0;
gdjs.Overworld4Code.GDBuy9Objects1.length = 0;
gdjs.Overworld4Code.GDBuy9Objects2.length = 0;
gdjs.Overworld4Code.GDBuy10Objects1.length = 0;
gdjs.Overworld4Code.GDBuy10Objects2.length = 0;
gdjs.Overworld4Code.GDTransitionObjects1.length = 0;
gdjs.Overworld4Code.GDTransitionObjects2.length = 0;
gdjs.Overworld4Code.GDTextBorderObjects1.length = 0;
gdjs.Overworld4Code.GDTextBorderObjects2.length = 0;

gdjs.Overworld4Code.eventsList0(runtimeScene);

return;

}

gdjs['Overworld4Code'] = gdjs.Overworld4Code;
