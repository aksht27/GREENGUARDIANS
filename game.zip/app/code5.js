gdjs.Overworld5Code = {};
gdjs.Overworld5Code.GDPlayerObjects1= [];
gdjs.Overworld5Code.GDPlayerObjects2= [];
gdjs.Overworld5Code.GDNPCObjects1= [];
gdjs.Overworld5Code.GDNPCObjects2= [];
gdjs.Overworld5Code.GDDock1Objects1= [];
gdjs.Overworld5Code.GDDock1Objects2= [];
gdjs.Overworld5Code.GDTree1Objects1= [];
gdjs.Overworld5Code.GDTree1Objects2= [];
gdjs.Overworld5Code.GDTree2Objects1= [];
gdjs.Overworld5Code.GDTree2Objects2= [];
gdjs.Overworld5Code.GDBush1Objects1= [];
gdjs.Overworld5Code.GDBush1Objects2= [];
gdjs.Overworld5Code.GDHouse1Objects1= [];
gdjs.Overworld5Code.GDHouse1Objects2= [];
gdjs.Overworld5Code.GDHouse2Objects1= [];
gdjs.Overworld5Code.GDHouse2Objects2= [];
gdjs.Overworld5Code.GDCornerWaterObjects1= [];
gdjs.Overworld5Code.GDCornerWaterObjects2= [];
gdjs.Overworld5Code.GDWaterCorner2Objects1= [];
gdjs.Overworld5Code.GDWaterCorner2Objects2= [];
gdjs.Overworld5Code.GDGrassObjects1= [];
gdjs.Overworld5Code.GDGrassObjects2= [];
gdjs.Overworld5Code.GDWaterEdgeRightObjects1= [];
gdjs.Overworld5Code.GDWaterEdgeRightObjects2= [];
gdjs.Overworld5Code.GDNewTiledSpriteObjects1= [];
gdjs.Overworld5Code.GDNewTiledSpriteObjects2= [];
gdjs.Overworld5Code.GDWater1Objects1= [];
gdjs.Overworld5Code.GDWater1Objects2= [];
gdjs.Overworld5Code.GDRoad1Objects1= [];
gdjs.Overworld5Code.GDRoad1Objects2= [];
gdjs.Overworld5Code.GDRoadEdge1Objects1= [];
gdjs.Overworld5Code.GDRoadEdge1Objects2= [];
gdjs.Overworld5Code.GDCollisionDetectObjects1= [];
gdjs.Overworld5Code.GDCollisionDetectObjects2= [];
gdjs.Overworld5Code.GDDialogueObjects1= [];
gdjs.Overworld5Code.GDDialogueObjects2= [];
gdjs.Overworld5Code.GDEObjects1= [];
gdjs.Overworld5Code.GDEObjects2= [];
gdjs.Overworld5Code.GDE2Objects1= [];
gdjs.Overworld5Code.GDE2Objects2= [];
gdjs.Overworld5Code.GDYesButtonObjects1= [];
gdjs.Overworld5Code.GDYesButtonObjects2= [];
gdjs.Overworld5Code.GDNoButtonObjects1= [];
gdjs.Overworld5Code.GDNoButtonObjects2= [];
gdjs.Overworld5Code.GDShadedDarkJoystickObjects1= [];
gdjs.Overworld5Code.GDShadedDarkJoystickObjects2= [];
gdjs.Overworld5Code.GDTargetRoundButtonObjects1= [];
gdjs.Overworld5Code.GDTargetRoundButtonObjects2= [];
gdjs.Overworld5Code.GDEmptyCloudBackgroundObjects1= [];
gdjs.Overworld5Code.GDEmptyCloudBackgroundObjects2= [];
gdjs.Overworld5Code.GDGreenSmallTree3Objects1= [];
gdjs.Overworld5Code.GDGreenSmallTree3Objects2= [];
gdjs.Overworld5Code.GDWoodYellowBarObjects1= [];
gdjs.Overworld5Code.GDWoodYellowBarObjects2= [];
gdjs.Overworld5Code.GDGoldObjects1= [];
gdjs.Overworld5Code.GDGoldObjects2= [];
gdjs.Overworld5Code.GDGreyButtonObjects1= [];
gdjs.Overworld5Code.GDGreyButtonObjects2= [];
gdjs.Overworld5Code.GDYellowButtonObjects1= [];
gdjs.Overworld5Code.GDYellowButtonObjects2= [];
gdjs.Overworld5Code.GDGreenButtonObjects1= [];
gdjs.Overworld5Code.GDGreenButtonObjects2= [];
gdjs.Overworld5Code.GDMaleCasualHoodieObjects1= [];
gdjs.Overworld5Code.GDMaleCasualHoodieObjects2= [];
gdjs.Overworld5Code.GDMaleCharacter9Objects1= [];
gdjs.Overworld5Code.GDMaleCharacter9Objects2= [];
gdjs.Overworld5Code.GDLargeExitButtonObjects1= [];
gdjs.Overworld5Code.GDLargeExitButtonObjects2= [];
gdjs.Overworld5Code.GDHelpObjects1= [];
gdjs.Overworld5Code.GDHelpObjects2= [];
gdjs.Overworld5Code.GDMenuObjects1= [];
gdjs.Overworld5Code.GDMenuObjects2= [];
gdjs.Overworld5Code.GDBlueButtonObjects1= [];
gdjs.Overworld5Code.GDBlueButtonObjects2= [];
gdjs.Overworld5Code.GDGreyButton2Objects1= [];
gdjs.Overworld5Code.GDGreyButton2Objects2= [];
gdjs.Overworld5Code.GDPlusObjects1= [];
gdjs.Overworld5Code.GDPlusObjects2= [];
gdjs.Overworld5Code.GDBlackSpaceObjects1= [];
gdjs.Overworld5Code.GDBlackSpaceObjects2= [];
gdjs.Overworld5Code.GDSmallGreenPlasticRoundToggleObjects1= [];
gdjs.Overworld5Code.GDSmallGreenPlasticRoundToggleObjects2= [];
gdjs.Overworld5Code.GDGreenLeavesObjects1= [];
gdjs.Overworld5Code.GDGreenLeavesObjects2= [];
gdjs.Overworld5Code.GDBuy3Objects1= [];
gdjs.Overworld5Code.GDBuy3Objects2= [];
gdjs.Overworld5Code.GDGreenBackgroundObjects1= [];
gdjs.Overworld5Code.GDGreenBackgroundObjects2= [];
gdjs.Overworld5Code.GDBuyObjects1= [];
gdjs.Overworld5Code.GDBuyObjects2= [];
gdjs.Overworld5Code.GDBuy2Objects1= [];
gdjs.Overworld5Code.GDBuy2Objects2= [];
gdjs.Overworld5Code.GDBuy4Objects1= [];
gdjs.Overworld5Code.GDBuy4Objects2= [];
gdjs.Overworld5Code.GDBuy5Objects1= [];
gdjs.Overworld5Code.GDBuy5Objects2= [];
gdjs.Overworld5Code.GDOnScreenControlsButtonObjects1= [];
gdjs.Overworld5Code.GDOnScreenControlsButtonObjects2= [];
gdjs.Overworld5Code.GDOnScreenControlsButton2Objects1= [];
gdjs.Overworld5Code.GDOnScreenControlsButton2Objects2= [];
gdjs.Overworld5Code.GDOnScreenControlsButton3Objects1= [];
gdjs.Overworld5Code.GDOnScreenControlsButton3Objects2= [];
gdjs.Overworld5Code.GDPlus2Objects1= [];
gdjs.Overworld5Code.GDPlus2Objects2= [];
gdjs.Overworld5Code.GDBuy6Objects1= [];
gdjs.Overworld5Code.GDBuy6Objects2= [];
gdjs.Overworld5Code.GDBuy7Objects1= [];
gdjs.Overworld5Code.GDBuy7Objects2= [];
gdjs.Overworld5Code.GDBuy8Objects1= [];
gdjs.Overworld5Code.GDBuy8Objects2= [];
gdjs.Overworld5Code.GDBuy9Objects1= [];
gdjs.Overworld5Code.GDBuy9Objects2= [];
gdjs.Overworld5Code.GDTransitionObjects1= [];
gdjs.Overworld5Code.GDTransitionObjects2= [];
gdjs.Overworld5Code.GDTextBorderObjects1= [];
gdjs.Overworld5Code.GDTextBorderObjects2= [];


gdjs.Overworld5Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Plus"), gdjs.Overworld5Code.GDPlusObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDPlusObjects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDPlusObjects1[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDPlusObjects1[k] = gdjs.Overworld5Code.GDPlusObjects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDPlusObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Overworld", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy6"), gdjs.Overworld5Code.GDBuy6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy6Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy6Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy6Objects1[k] = gdjs.Overworld5Code.GDBuy6Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy6Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy5"), gdjs.Overworld5Code.GDBuy5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy5Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy5Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy5Objects1[k] = gdjs.Overworld5Code.GDBuy5Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy5Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy3"), gdjs.Overworld5Code.GDBuy3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy3Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy3Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy3Objects1[k] = gdjs.Overworld5Code.GDBuy3Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy3Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy7"), gdjs.Overworld5Code.GDBuy7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy7Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy7Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy7Objects1[k] = gdjs.Overworld5Code.GDBuy7Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy7Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy8"), gdjs.Overworld5Code.GDBuy8Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy8Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy8Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy8Objects1[k] = gdjs.Overworld5Code.GDBuy8Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy8Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy9"), gdjs.Overworld5Code.GDBuy9Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Overworld5Code.GDBuy9Objects1.length;i<l;++i) {
    if ( gdjs.Overworld5Code.GDBuy9Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Overworld5Code.GDBuy9Objects1[k] = gdjs.Overworld5Code.GDBuy9Objects1[i];
        ++k;
    }
}
gdjs.Overworld5Code.GDBuy9Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("", runtimeScene);
}}

}


};

gdjs.Overworld5Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Overworld5Code.GDPlayerObjects1.length = 0;
gdjs.Overworld5Code.GDPlayerObjects2.length = 0;
gdjs.Overworld5Code.GDNPCObjects1.length = 0;
gdjs.Overworld5Code.GDNPCObjects2.length = 0;
gdjs.Overworld5Code.GDDock1Objects1.length = 0;
gdjs.Overworld5Code.GDDock1Objects2.length = 0;
gdjs.Overworld5Code.GDTree1Objects1.length = 0;
gdjs.Overworld5Code.GDTree1Objects2.length = 0;
gdjs.Overworld5Code.GDTree2Objects1.length = 0;
gdjs.Overworld5Code.GDTree2Objects2.length = 0;
gdjs.Overworld5Code.GDBush1Objects1.length = 0;
gdjs.Overworld5Code.GDBush1Objects2.length = 0;
gdjs.Overworld5Code.GDHouse1Objects1.length = 0;
gdjs.Overworld5Code.GDHouse1Objects2.length = 0;
gdjs.Overworld5Code.GDHouse2Objects1.length = 0;
gdjs.Overworld5Code.GDHouse2Objects2.length = 0;
gdjs.Overworld5Code.GDCornerWaterObjects1.length = 0;
gdjs.Overworld5Code.GDCornerWaterObjects2.length = 0;
gdjs.Overworld5Code.GDWaterCorner2Objects1.length = 0;
gdjs.Overworld5Code.GDWaterCorner2Objects2.length = 0;
gdjs.Overworld5Code.GDGrassObjects1.length = 0;
gdjs.Overworld5Code.GDGrassObjects2.length = 0;
gdjs.Overworld5Code.GDWaterEdgeRightObjects1.length = 0;
gdjs.Overworld5Code.GDWaterEdgeRightObjects2.length = 0;
gdjs.Overworld5Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Overworld5Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Overworld5Code.GDWater1Objects1.length = 0;
gdjs.Overworld5Code.GDWater1Objects2.length = 0;
gdjs.Overworld5Code.GDRoad1Objects1.length = 0;
gdjs.Overworld5Code.GDRoad1Objects2.length = 0;
gdjs.Overworld5Code.GDRoadEdge1Objects1.length = 0;
gdjs.Overworld5Code.GDRoadEdge1Objects2.length = 0;
gdjs.Overworld5Code.GDCollisionDetectObjects1.length = 0;
gdjs.Overworld5Code.GDCollisionDetectObjects2.length = 0;
gdjs.Overworld5Code.GDDialogueObjects1.length = 0;
gdjs.Overworld5Code.GDDialogueObjects2.length = 0;
gdjs.Overworld5Code.GDEObjects1.length = 0;
gdjs.Overworld5Code.GDEObjects2.length = 0;
gdjs.Overworld5Code.GDE2Objects1.length = 0;
gdjs.Overworld5Code.GDE2Objects2.length = 0;
gdjs.Overworld5Code.GDYesButtonObjects1.length = 0;
gdjs.Overworld5Code.GDYesButtonObjects2.length = 0;
gdjs.Overworld5Code.GDNoButtonObjects1.length = 0;
gdjs.Overworld5Code.GDNoButtonObjects2.length = 0;
gdjs.Overworld5Code.GDShadedDarkJoystickObjects1.length = 0;
gdjs.Overworld5Code.GDShadedDarkJoystickObjects2.length = 0;
gdjs.Overworld5Code.GDTargetRoundButtonObjects1.length = 0;
gdjs.Overworld5Code.GDTargetRoundButtonObjects2.length = 0;
gdjs.Overworld5Code.GDEmptyCloudBackgroundObjects1.length = 0;
gdjs.Overworld5Code.GDEmptyCloudBackgroundObjects2.length = 0;
gdjs.Overworld5Code.GDGreenSmallTree3Objects1.length = 0;
gdjs.Overworld5Code.GDGreenSmallTree3Objects2.length = 0;
gdjs.Overworld5Code.GDWoodYellowBarObjects1.length = 0;
gdjs.Overworld5Code.GDWoodYellowBarObjects2.length = 0;
gdjs.Overworld5Code.GDGoldObjects1.length = 0;
gdjs.Overworld5Code.GDGoldObjects2.length = 0;
gdjs.Overworld5Code.GDGreyButtonObjects1.length = 0;
gdjs.Overworld5Code.GDGreyButtonObjects2.length = 0;
gdjs.Overworld5Code.GDYellowButtonObjects1.length = 0;
gdjs.Overworld5Code.GDYellowButtonObjects2.length = 0;
gdjs.Overworld5Code.GDGreenButtonObjects1.length = 0;
gdjs.Overworld5Code.GDGreenButtonObjects2.length = 0;
gdjs.Overworld5Code.GDMaleCasualHoodieObjects1.length = 0;
gdjs.Overworld5Code.GDMaleCasualHoodieObjects2.length = 0;
gdjs.Overworld5Code.GDMaleCharacter9Objects1.length = 0;
gdjs.Overworld5Code.GDMaleCharacter9Objects2.length = 0;
gdjs.Overworld5Code.GDLargeExitButtonObjects1.length = 0;
gdjs.Overworld5Code.GDLargeExitButtonObjects2.length = 0;
gdjs.Overworld5Code.GDHelpObjects1.length = 0;
gdjs.Overworld5Code.GDHelpObjects2.length = 0;
gdjs.Overworld5Code.GDMenuObjects1.length = 0;
gdjs.Overworld5Code.GDMenuObjects2.length = 0;
gdjs.Overworld5Code.GDBlueButtonObjects1.length = 0;
gdjs.Overworld5Code.GDBlueButtonObjects2.length = 0;
gdjs.Overworld5Code.GDGreyButton2Objects1.length = 0;
gdjs.Overworld5Code.GDGreyButton2Objects2.length = 0;
gdjs.Overworld5Code.GDPlusObjects1.length = 0;
gdjs.Overworld5Code.GDPlusObjects2.length = 0;
gdjs.Overworld5Code.GDBlackSpaceObjects1.length = 0;
gdjs.Overworld5Code.GDBlackSpaceObjects2.length = 0;
gdjs.Overworld5Code.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.Overworld5Code.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.Overworld5Code.GDGreenLeavesObjects1.length = 0;
gdjs.Overworld5Code.GDGreenLeavesObjects2.length = 0;
gdjs.Overworld5Code.GDBuy3Objects1.length = 0;
gdjs.Overworld5Code.GDBuy3Objects2.length = 0;
gdjs.Overworld5Code.GDGreenBackgroundObjects1.length = 0;
gdjs.Overworld5Code.GDGreenBackgroundObjects2.length = 0;
gdjs.Overworld5Code.GDBuyObjects1.length = 0;
gdjs.Overworld5Code.GDBuyObjects2.length = 0;
gdjs.Overworld5Code.GDBuy2Objects1.length = 0;
gdjs.Overworld5Code.GDBuy2Objects2.length = 0;
gdjs.Overworld5Code.GDBuy4Objects1.length = 0;
gdjs.Overworld5Code.GDBuy4Objects2.length = 0;
gdjs.Overworld5Code.GDBuy5Objects1.length = 0;
gdjs.Overworld5Code.GDBuy5Objects2.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButtonObjects1.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButtonObjects2.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButton2Objects1.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButton2Objects2.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButton3Objects1.length = 0;
gdjs.Overworld5Code.GDOnScreenControlsButton3Objects2.length = 0;
gdjs.Overworld5Code.GDPlus2Objects1.length = 0;
gdjs.Overworld5Code.GDPlus2Objects2.length = 0;
gdjs.Overworld5Code.GDBuy6Objects1.length = 0;
gdjs.Overworld5Code.GDBuy6Objects2.length = 0;
gdjs.Overworld5Code.GDBuy7Objects1.length = 0;
gdjs.Overworld5Code.GDBuy7Objects2.length = 0;
gdjs.Overworld5Code.GDBuy8Objects1.length = 0;
gdjs.Overworld5Code.GDBuy8Objects2.length = 0;
gdjs.Overworld5Code.GDBuy9Objects1.length = 0;
gdjs.Overworld5Code.GDBuy9Objects2.length = 0;
gdjs.Overworld5Code.GDTransitionObjects1.length = 0;
gdjs.Overworld5Code.GDTransitionObjects2.length = 0;
gdjs.Overworld5Code.GDTextBorderObjects1.length = 0;
gdjs.Overworld5Code.GDTextBorderObjects2.length = 0;

gdjs.Overworld5Code.eventsList0(runtimeScene);

return;

}

gdjs['Overworld5Code'] = gdjs.Overworld5Code;
